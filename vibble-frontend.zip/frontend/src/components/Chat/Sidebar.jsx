import React from 'react';

const Sidebar = () => {
  return (
    <div className="w-1/4 border-r p-4">
      <h2 className="font-bold text-lg mb-4">Chats</h2>
      {/* TODO: map contacts here */}
    </div>
  );
};

export default Sidebar;
